package forgingaura.forgeyourworld.proxy;

public interface CommonProxy {
	
	public void init();
	public void preInit();

}
